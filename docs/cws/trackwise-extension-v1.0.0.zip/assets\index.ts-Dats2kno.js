(function(){function s(t){for(const e of t){const n=document.querySelector(e)?.textContent?.trim();if(n)return n}return null}const f={name:"linkedin",readySelector:"h1.t-24, .job-details-jobs-unified-top-card__job-title, .jobs-unified-top-card__job-title",matches(t){try{const e=new URL(t);return e.hostname!=="www.linkedin.com"?!1:!!(e.pathname.startsWith("/jobs/view/")||e.searchParams.has("currentJobId"))}catch{return!1}},parse(){const t=s(["h1.t-24",".job-details-jobs-unified-top-card__job-title h1",".job-details-jobs-unified-top-card__job-title",".jobs-unified-top-card__job-title h1",".jobs-unified-top-card__job-title"]),e=s([".job-details-jobs-unified-top-card__company-name a",".job-details-jobs-unified-top-card__company-name",".jobs-unified-top-card__company-name a",".jobs-unified-top-card__company-name"]),o=s([".job-details-jobs-unified-top-card__primary-description-container .tvm__text",".jobs-unified-top-card__bullet"]);return{company:e,role:t,location:o,salary_min:null,salary_max:null,source_url:window.location.href,source_site:"linkedin",notes:null}}};function i(t){for(const e of t){const n=document.querySelector(e)?.textContent?.trim();if(n)return n}return null}const m={name:"indeed",readySelector:'[data-testid="jobsearch-JobInfoHeader-title"], .jobsearch-JobInfoHeader-title',matches(t){try{const e=new URL(t);return e.hostname!=="indeed.com"&&!e.hostname.endsWith(".indeed.com")?!1:!!(e.pathname==="/viewjob"&&e.searchParams.has("jk")||e.pathname==="/jobs"&&e.searchParams.has("vjk"))}catch{return!1}},parse(){const e=i(['[data-testid="jobsearch-JobInfoHeader-title"]',".jobsearch-JobInfoHeader-title"])?.replace(/\s*-\s*job post\s*$/i,"").trim()??null,o=i(['[data-testid="inlineHeader-companyName"] a','[data-testid="inlineHeader-companyName"]',".jobsearch-CompanyInfoContainer a",".jobsearch-CompanyInfoWithoutHeaderImage a"]),n=i(['[data-testid="inlineHeader-companyLocation"]','[data-testid="job-location"]']);return{company:o,role:e,location:n,salary_min:null,salary_max:null,source_url:window.location.href,source_site:"indeed",notes:null}}},b=[f,m];let r=null,d=location.href;function h(t,e){const o=document.querySelector(t);return o?Promise.resolve(o):new Promise(n=>{const a=new MutationObserver(()=>{const c=document.querySelector(t);c&&(a.disconnect(),n(c))});a.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{a.disconnect(),n(document.querySelector(t))},e)})}function p(){r&&(r.remove(),r=null)}const y=80,_=12;function j(){const t=[".scaffold-layout__main",".jobs-search-two-pane__details","main"];for(const e of t){const n=document.querySelector(e)?.getBoundingClientRect();if(n&&n.width>0)return n.right}return null}function u(t){const e=j();if(t.style.top=`${y}px`,t.style.bottom="auto",e!==null){const o=e+_;o+160<=window.innerWidth?(t.style.left=`${o}px`,t.style.right="auto"):(t.style.left="auto",t.style.right="24px")}else t.style.left="auto",t.style.right="24px"}function x(t){const e=document.createElement("div");e.id="trackwise-host",Object.assign(e.style,{position:"fixed",zIndex:"2147483647"}),u(e);const o=e.attachShadow({mode:"closed"}),n=document.createElement("style");n.textContent=`
    button {
      font: 500 14px system-ui, -apple-system, sans-serif;
      letter-spacing: 0.01em;
      padding: 11px 18px;
      border: none;
      border-radius: 8px;
      background: #0f172a;
      color: white;
      cursor: pointer;
      white-space: nowrap;
      box-shadow: 0 4px 12px rgba(15, 23, 42, 0.25), 0 1px 3px rgba(0, 0, 0, 0.08);
      transition: background 0.15s ease, transform 0.15s ease, box-shadow 0.15s ease;
    }
    button:hover {
      background: #1e293b;
      transform: translateY(-1px);
      box-shadow: 0 6px 16px rgba(15, 23, 42, 0.3), 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    button:active { transform: translateY(0); }
    button:disabled { cursor: default; opacity: 0.9; transform: none; }
    button.success { background: #047857; }
    button.success:hover { background: #047857; }
    button.error { background: #b91c1c; }
    button.error:hover { background: #b91c1c; }
  `,o.appendChild(n);const a=document.createElement("button");a.textContent="Save to TrackWise",a.addEventListener("click",()=>g(t,a)),o.appendChild(a),document.body.appendChild(e),r=e}async function g(t,e){e.disabled=!0,e.className="",e.textContent="Saving...";try{const n={type:"save_application",payload:t.parse()},a=await chrome.runtime.sendMessage(n);if(!a.ok)throw new Error(a.error);e.className="success",e.textContent="Saved"}catch(o){e.className="error",e.textContent=o instanceof Error?o.message:"Error"}setTimeout(()=>{e.disabled=!1,e.className="",e.textContent="Save to TrackWise"},2500)}async function l(){p();const t=b.find(o=>o.matches(location.href));if(!(!t||!await h(t.readySelector,3e4))&&t.matches(location.href))try{x(t)}catch(o){console.error("TrackWise: failed to inject save button",o)}}function w(){l(),setInterval(()=>{location.href!==d&&(d=location.href,l())},500),window.addEventListener("resize",()=>{r&&u(r)})}try{w()}catch(t){console.error("TrackWise: content script failed to start",t)}
})()
